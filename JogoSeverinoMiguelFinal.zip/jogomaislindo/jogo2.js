//variáveis auxiliares
var i, j, k, o, b, p, r1, r2, r3, u;
//variáveis de fase
var menu = true, pause = false, fase1 = false, fase2 = false, fase3 = false; faseAtual = 0;
//variáveis para saber se ganhou a fase
var ganhar1 = false, ganhar2 = false, ganhar3 = false, perder1 = false, perder2 = false, perder3 = false;
//variáveis de transição de telas do jogo
var tela1 = false, tela2 = false, tela3 = false, tela4 = false, tela5 =false, tela6 = false, telaFIm = false;
//variáveis de jogador
var jogadorx, jogadory;
//variáveis de tiro
var tirox, tiroy, velattack = 10, tiro = false;
//variáveis inimigos da primeira fase
var inimigo1x = []
var inimigo1y = []
var vel1y = []
var qt_inimigo1 = 0
var pass1 = 0;
//variáveis inimigos da segunda fase
var inimigo2x = []
var inimigo2y = []
var vel2y = []
var qt_inimigo2 = 0
var pass2 = 0;
//variáveis inimigos da terceira fase
var inimigo3x = []
var inimigo3y = []
var vel3y = []
var qt_inimigo3 = 0
var pass3 = 0;
//variaveis de pontuação e vida
var score1 = 0, score2 = 0, score3 = 0;
var health1 = 5, health2, health3;
//variaáveis de upgrade
var orange1 = false, tempo_orange = 1000; orange_ativiado = false;
var orangex, orangey;
var blue1 = false, tempo_blue = 600, blue_ativado = false;
var bluex, bluey;
var purple1 = false, tempo_purple = 600, purple_ativado = false;
var purplex, purpley;
var splashx = 0, splashy = 0;//especifica do purple
//variáveis bonus
var redx = [], redy = [], velred = [];
//variáveis para saber se coletou os upgrade
var coletou1 = false, coletou2 = false, coletou3 = false;
//varriaveis dos sons
var somtiro, musicamenu, musicajogo, musicafim;
//variaveis das imagens 
var nave, inimigofase1, inimigofase2, inimigofase3, laser, upgradelife, upgradegelo, upgradevel, upgradeshot;
var background1, background2, background3, backgroundMenu, backgroundPause, backgroundFim, luzlaser;
var setas, spacebar, letraq, letraw, letrae;
//variaveis de distancia
var distancialife, distanciavelocidade, distanciagelo, distanciashot;


function preload(){
	//carregamento de sons
	somtiro = loadSound("sounds/LaserShot.wav");
	musicamenu = loadSound("sounds/menucortado.mp3");
	musicajogo = loadSound("sounds/stevenuniverse.mp3");
	musicafim = loadSound("sounds/wearethechampions.mp3");
}

function setup(){
	createCanvas(500, 640);
	//carregamento de fonte 
	Font = loadFont("fonte/fontejogo.otf");
	//carregamento de imagens
	nave = loadImage("imagens/naves/ship1.png");
	inimigofase1 = loadImage("imagens/naves/ship2.png");
	inimigofase2 = loadImage("imagens/naves/ship3.png");
	inimigofase3 = loadImage("imagens/naves/ship4.png");
	backgroundMenu = loadImage("imagens/cenario/wallpaper.jpeg");
	background1 = loadImage("imagens/cenario/backgroundfase1.jpg");
	background2 = loadImage("imagens/cenario/backgroundfase2.jpg");
	background3 = loadImage("imagens/cenario/backgroundfase3.jpg");
	backgroundFim = loadImage("imagens/");
	backgroundPause = loadImage("imagens/");
	backgroundFail = loadImage("imagens/cenario/perdeu.jpg");
	backgroundFase = loadImage("imagens/");
	laser = loadImage("imagens/tiro/laserRed.png");
	luzlaser = loadImage("imagens/tiro/laserRedShot.png")
	upgradelife = loadImage("imagens/upgrades/heart1.png");
	upgradegelo = loadImage("imagens/upgrades/bonusgelo1.png");
	upgradevel = loadImage("imagens/upgrades/bonusvel1.png");
	upgradeshot = loadImage("imagens/upgrades/bonusshot1.png");
	spacebar = loadImage("imagens/tiro/spacebar.png");
	setas = loadImage("imagens/tiro/setasED.png");
	letraq =loadImage("imagens/tiro/teclaQ.png");
	letraw =loadImage("imagens/tiro/teclaW.png");
	letrae =loadImage("imagens/tiro/teclaE.png");
	//posição inicial do jogador
	jogadorx = width/2;
	jogadory = 570;
	//inimigos da primeira fase
	reset_1();
	//inimigos da segunda fase
	reset_2();
	//inimigos da terceira fase
	reset_3();
	//bonus de vida
	reset_bonus();
	//upgrades
	reset_upgrades();
}

function draw(){
	background(backgroundMenu);
	distanciashot = dist(jogadorx+15, jogadory+15, purplex, purpley);
	distanciagelo = dist(jogadorx+15, jogadory+15, bluex, bluey);
	distanciavelocidade = dist(jogadorx+15, jogadory+15, orangex, orangey);
	//inicia com menu 
	if(menu == true){
		enter_menu();
		if(!musicamenu.isPlaying()){
		musicamenu.setVolume(0.1);
	 	musicamenu.play();
 		}
	}
	if(faseAtual == 1 || faseAtual == 2 || faseAtual == 3){
		if(musicamenu.isPlaying()){
	 	musicamenu.stop();
	 	}
	 	if(!musicajogo.isPlaying()){
		musicajogo.setVolume(0.1);
	 	musicajogo.play();
 		}
	}
	if(faseAtual == 1){
		fase1 = true;
		fase2 = false;
		fase3 = false;
	}
	if(faseAtual == 2){
		fase1 = false;
		fase2 = true;
		fase3 = false;
	}
	if(faseAtual == 3){
		fase1 = false;
		fase2 = false;
		fase3 = true;
	}
	
	if(fase1 == true){
		fase_1();
		upgrade_orange();
		upgrade_blue();
		upgrade_purple();	
		jogador();
		atirar();
		pontuacao();
		vida();
		collide_upgrade_1();
	}
	if(fase2 == true){
		fase_2();
		upgrade_orange();
		upgrade_blue();
		upgrade_purple();	
		jogador();
		atirar();
		pontuacao();
		vida();
		collide_upgrade_1();
		collide_upgrade_2();
	}
	if(fase3 == true){
		fase_3();
		upgrade_orange();
		upgrade_blue();
		upgrade_purple();	
		jogador();
		atirar();
		pontuacao();
		vida();
		collide_upgrade_1();
		collide_upgrade_2();
		collide_upgrade_3();
	}
	//pausa o jogo
	if(pause == true){
		pause_menu();
	}
	if(tela1 == true){
		background(backgroundMenu);
		textFont(Font);
		textSize(80);
		fill(255, 255, 255);
		text('You Won', 180, 440);
		textSize(40);
		text('score '+score1, 20, 30);
		textSize(40);
		text('Next stage', 180, 480);
		textSize(30);
		text('(Press ENTER)', 180, 500);

	}
	if(tela2 == true){
		background(backgroundMenu);
		textFont(Font);
		textSize(80);
		fill(255, 255, 255);
		text('You Won', 180, 440);
		textSize(40);
		text('score '+score2, 20, 30);
		textSize(40);
		text('Next stage', 180, 480);
		textSize(30);
		text('(Press ENTER)', 180, 500);
	}
	if(tela3 == true){
		background(backgroundMenu);
		textFont(Font);
		textSize(80);
		fill(255, 255, 255);
		text('Congratulations!', 90, 440);
		textSize(40);
		text('score '+score3, 20, 30);
		textSize(40);
		text('You Won', 180, 480);
		textSize(30);
		text('(Press ENTER)', 180, 500);
	}
	if(tela4 == true){
		background(backgroundFail);
		textFont(Font);
		textSize(60);
		fill(255, 255, 255);
		text('You Failed', 180, 600);
		textSize(40);
		text('score '+score1, 20, 30);
		textSize(40);
		text('Try Again'+' (Press ENTER)', 140, 630);
	}
	if(tela5 == true){
		background(backgroundFail);
		textFont(Font);
		textSize(60);
		fill(255, 255, 255);
		text('You Failed', 180, 600);
		textSize(40);
		text('score '+score2, 20, 30);
		text('Try Again'+' (Press ENTER)', 140, 630);
	}
	if(tela6 == true){
		background(backgroundFail);
		textFont(Font);
		textSize(60);
		fill(255, 255, 255);
		text('You Failed', 180, 600);
		textSize(40);
		text('score '+score3, 20, 30);
		text('Try Again'+' (Press ENTER)', 140, 630);
	}
	if(telaFIm == true){
		tela_final();
		if(musicajogo.isPlaying()){
	 	musicajogo.stop();
 		}
 		if(!musicafim.isPlaying()){
		musicafim.setVolume(0.1);
	 	musicafim.play();
 		}
	}
}

function enter_menu(){
	textFont(Font);
	textSize(60);
	fill(255, 255, 255);
	text('START', 210, 400);
	textSize(40);
	text('(Press ENTER)', 185, 420);
	textSize(60)
	text('Pause and Instructions', 100, 470);
	textSize(40);
	text('(Press P)', 208, 490);
}

function pause_menu(){
	background(backgroundMenu);
	textFont(Font);
	textSize(80);
	fill(255, 255, 255);
	text('Paused', 190, 350);
	textSize(60);
	text("Instructions:", 160, 390);
	textSize(50);
	text("movement", 200, 420);
	image(setas, 207, 430, 90, 30);
	textSize(50);
	text("shot", 230, 500);
	image(spacebar, 160, 510, 190, 30);
	text("activate bonus", 170, 570);
	image(upgradevel, 160, 580, 50, 50);
	image(upgradegelo, 260, 580, 50, 50);
	image(upgradeshot, 360, 580, 50, 50);
	image(letraq, 120, 590, 30, 30);
	image(letraw, 220, 590, 30, 30);
	image(letrae, 320, 590, 30, 30);

}

function jogador(){
	image(nave, jogadorx, jogadory, 70, 70);

	if(keyIsDown(37)){
		jogadorx -= 8;
	}
	if(keyIsDown(39)){
		jogadorx += 8;
	}
	if(jogadorx > 500){
		jogadorx -= 8;
	}
	if(jogadorx < 0){
		jogadorx += 8;
	}
}

function atirar(){
	if(keyIsDown(32) && tiro == false){
		somtiro.setVolume(0.1);
 		somtiro.play();
		tirox = jogadorx+32;
		tiroy = jogadory;
		tiro = true
	}
	if(tiro == true){
		tiroy -= velattack;
	}
	if(tiroy < -15){
		tiro = false;
	}
	if(orange_ativiado == true){
		image(laser, tirox, tiroy, 5, 20);
	}else{
		if(purple_ativado == true){
			image(laser, tirox, tiroy, 50, 200);
		}else{
			image(laser, tirox, tiroy, 5, 20);
		}
	}
}

function keyPressed(){
	if(keyCode == 13){
		if(menu == true){
			menu = false;
			faseAtual = 1;
		}
		if(telaFIm == true){
			telaFIm = false;
			menu = true;
			faseAtual = 0;
			reset_1();
			reset_2();
			reset_3();
			reset_bonus();
			reset_upgrades();
			reset_variaveis();
			health1 = 5;
			enter_menu();
		}
		if(ganhar1 == true){
			loop();
			tela1 = false;
			faseAtual = 2;
			//jogador volta para posição original
			jogadorx = width/2;
			jogadory = 570;
			//tiro volta para posição do jogador
			tiro = false;
			tiroy = jogadory + 200;
		}
		if(perder1 == true){
			health1 = 5;
			pass1 = 0;
			score1 = 0;
			loop();
			reset_1();
			reset_bonus();
			reset_upgrades();
			reset_variaveis();
			tela4 = false;
			faseAtual = 1;
			perder1 = false;
		}
		if(ganhar2 == true){
			loop();
			tela2 = false;
			faseAtual = 3;
			jogadorx = width/2;
			jogadory = 570;
			tiro = false;
			tiroy = jogadory + 200;
		}
		if(perder2 == true){
			health2 = health1;
			score2 = 0;
			pass2 = 0;
			loop();
			reset_bonus();
			reset_2();
			reset_upgrades();
			reset_variaveis();
			tela5 = false;
			faseAtual = 2;
			perder2 = false;
		}
		if(ganhar3 == true){
			loop();
			tela3 = false;
			telaFIm = true;
		}
		if(perder3 == true){
			health3 = health2 + 5;
			score3 = 0;
			pass3 = 0;
			loop();
			reset_3();
			reset_bonus();
			reset_upgrades();
			reset_variaveis();
			tela6 = false;
			faseAtual = 3;
			perder3 = false;
		}
	}
	if(keyCode == 80){
		if(pause == false){
			noLoop();
			pause = true
		}else{
			loop();
			pause = false;
		}
	}
	if(keyCode == 81){
		orange_ativiado = true;
	}
	if(keyCode == 87){
		blue_ativado = true;
	}
	if(keyCode == 69){
		purple_ativado = true;
	}
}

function fase_1(){
	if(fase1 == true){
		background(background1);

		textFont(Font);
		textSize(45);
		fill(230, 0, 92);
		text('stage 1', 200, 40);

		textFont(Font);
		textSize(20);
		fill(230, 0, 92);
		text('Enemies '+qt_inimigo1+"/30", 205, 60);

		for(i = 0; i < 30; i++){
			if(blue1 == true && blue_ativado == true){
				inimigo1y[i] = inimigo1y[i] + 0.25;
			}else{
				inimigo1y[i] = inimigo1y[i] + vel1y[i];
			}	
			image(inimigofase1, inimigo1x[i], inimigo1y[i], 55, 55);
		}
		for(i = 0; i < 30; i++){
			if(tirox>inimigo1x[i] && tirox<inimigo1x[i]+50+splashx && tiroy<inimigo1y[i]+40+splashy && tiroy>inimigo1y[i]){
				image(luzlaser, inimigo1x[i]+10, inimigo1y[i]+10, 40, 40);
				if(orange1 == true && orange_ativiado == true){
					velattack = 30;
				}else{
					if(purple1 == true && purple_ativado == true){
						splashx = 100;
						splashy = 100;
						tiro = false;
						tiroy = jogadory + 200;
					}else{
						splashx = 0;
						splashy = 0;
						velattack = 10;
						tiro = false;
						tiroy = jogadory + 200;
					}
				}
		
				inimigo1y[i] = 1000;
				qt_inimigo1++;
				score1++;
			}
			if(inimigo1y[i] > 640 && inimigo1y[i] < 641){
				health1--;
			}
		}
		for(r1 = 0; r1 < 1; r1++){
			redy[r1] = redy[r1] + velred[r1]
			image(upgradelife, redx[r1], redy[r1], 20, 20);
		}
		for(r1 = 0; r1 < 1; r1++){
			distancialifefase1 = dist(jogadorx+15, jogadory+15, redx[r1], redy[r1]);
			if(distancialifefase1<30){
				redy[r1] = 1000;
				health1+=3;
			}
		}
	}

	if(score1 >= 20 && health1 > 0){
		noLoop();
		tela_1();
		ganhar1 = true;
		health2 = health1;
	}
	if(health1 <= 0 || pass1 > 6){
		tela_4();
		perder1 = true;
	}
}

function fase_2(){
	if(fase2 == true){
		background(background2);
		textFont(Font);
		textSize(45);
		fill(230, 0, 92);
		text('stage 2', 200, 40);

		textFont(Font);
		textSize(20);
		fill(230, 0, 92);
		text('Enemies '+qt_inimigo2+"/60", 205, 60);

		for(j = 0; j < 60; j++){
			if(blue1 == true && blue_ativado == true){
				inimigo2y[j] = inimigo2y[j] + 0.25;
			}else{
				inimigo2y[j] = inimigo2y[j] + vel2y[j];
			}
			image(inimigofase2, inimigo2x[j], inimigo2y[j], 55, 55);
		}
		for(j = 0; j < 60; j++){
			if(tirox>inimigo2x[j] && tirox<inimigo2x[j]+45+splashx && tiroy<inimigo2y[j]+40+splashy && tiroy>inimigo2y[j]){
				image(luzlaser, inimigo2x[j]+10, inimigo2y[j]+10, 40, 40);
				if(orange1 == true  && orange_ativiado == true){
					velattack = 30;
				}else{
					if(purple1 == true && purple_ativado == true){
						splashx = 100;
						splashy = 100;
						tiro = false;
						tiroy = jogadory + 200;
					}else{
						splashx = 0;
						splashy = 0;
						velattack = 10;
						tiro = false;
						tiroy = jogadory + 200;
					}
				}

				inimigo2y[j] = 1000;
				qt_inimigo2++;
				score2++;
			}
			if(inimigo2y[j] > 640 && inimigo2y[j] < 642){
				health2--;
			}
		}
		for(r2 = 0; r2 < 2; r2++){
			noStroke();
			fill(255, 0, 0);
			redy[r2] = redy[r2] + velred[r2]
			image(upgradelife,redx[r2], redy[r2], 20, 20);
		}
		for(r2 = 0; r2 < 2; r2++){
			distancialifefase2 = dist(jogadorx+15, jogadory+15, redx[r2], redy[r2]);
			if(distancialifefase2<30){
				redy[r2] = 1000;
				health2+=3;
			}
		}
	}
	if(score2 >= 30 && health2 > 0){
		noLoop();
		tela_2();
		ganhar2 = true;
		health3 = health2;
	}
	if(health2 <= 0 || pass2 > 12){
		noLoop()
		tela_5();
		perder2 = true;
	}
}

function fase_3(){
	if(fase3 == true){
		background(background3);

		textFont(Font);
		textSize(45);
		fill(230, 0, 92);
		text('stage 3', 200, 40);

		textFont(Font);
		textSize(20);
		fill(230, 0, 92);
		text('Enemies '+qt_inimigo3+"/90", 205, 60);

		for(k = 0; k < 90; k++){
			if(blue1 == true && blue_ativado == true){
				inimigo3y[k] = inimigo3y[k] + 0.25;
			}else{
				inimigo3y[k] = inimigo3y[k] + vel3y[k];
			}
			image(inimigofase3, inimigo3x[k], inimigo3y[k], 55, 55);
		}
		for(k = 0; k < 90; k++){
			if(tirox>inimigo3x[k] && tirox<inimigo3x[k]+50+splashx && tiroy<inimigo3y[k]+40+splashy && tiroy>inimigo3y[k]){
				image(luzlaser, inimigo3x[k]+10, inimigo3y[k]+10, 40, 40);
				if(orange1 == true  && orange_ativiado == true){
					velattack = 30;
				}else{
					if(purple1 == true && purple_ativado == true){
						splashx = 100;
						splashy = 100;
						tiro = false;
						tiroy = jogadory + 200;
					}else{
						splashx = 0;
						splashy = 0;
						velattack = 10;
						tiro = false;
						tiroy = jogadory + 200;
					}
				}

				inimigo3y[k] = 1000;
				qt_inimigo3++;
				score3++;
			}
			if(inimigo3y[k] > 640 && inimigo3y[k] < 643){
				health3--;
			}
		}
		for(r3 = 0; r3 < 3; r3++){
			noStroke();
			fill(255, 0, 0);
			redy[r3] = redy[r3] + velred[r3]
			image(upgradelife,redx[r3], redy[r3], 20, 20);
		}
		for(r3 = 0; r3 < 3; r3++){
			distancialifefase3 = dist(jogadorx+15, jogadory+15, redx[r3], redy[r3]);
			if(distancialifefase3<30){
				redy[r3] = 1000;
				health3+=5;
			}
		}
	}
	if(score3 >= 50 && health3 > 0){
		noLoop();
		tela_3();
		ganhar3 = true;
	}
	if(health3 <= 0 || pass3 > 18){
		noLoop();
		tela_6();
		perder3 = true;
	}
}

function pontuacao(){
	if(faseAtual == 1){
		textFont(Font);
		textSize(30);
		fill(255, 255, 255);
		text('score '+score1, 20, 30);
	}else{
		if(faseAtual == 2){
			textFont(Font);
			textSize(30);
			fill(255, 255, 255);
			text('score '+score2, 20, 30);
		}else{
			if(faseAtual == 3){
				textFont(Font);
				textSize(30);
				fill(255, 255, 255);
				text('score '+score3, 20, 30);
			}
		}
	}
}

function vida(){
	if(faseAtual == 1){
		image(upgradelife, 14, 41, 30, 30)
		textFont(Font);
		textSize(30);
		fill(255, 255, 255);
		text(health1, 25, 60);
	}else{
		if(faseAtual == 2){
			image(upgradelife, 14, 41, 30, 30)
			textFont(Font);
			textSize(30);
			fill(255, 255, 255);
			text(health2, 25, 60);
		}else{
			if(faseAtual == 3){
				image(upgradelife, 14, 41, 30, 30)
				textFont(Font);
				textSize(30);
				fill(255, 255, 255);
				text(health3, 25, 60);
			}
		}
	}
}

function upgrade_orange(){
	if(orange1 == true){
		if(orange_ativiado == true){
			velattack = 25
			tempo_orange--;
			textFont(Font);
			textSize(25);
			fill(255, 102, 0);
			if(tempo_orange >= 0){
				textFont(Font);
				text(tempo_orange, 60, 210);
			}else{
				orange1 = false;
				orange_ativiado = false;
				tempo_orange = 0;
			}
		}else{

		}
		image(upgradevel, 35, 200, 35, 35);
	}
}

function upgrade_blue(){
	if(blue1 == true){
		if(blue_ativado == true){
			tempo_blue--;
			textFont(Font);
			textSize(25);
			fill(0, 255, 255);
			if(tempo_blue >= 0){
				textFont(Font);
				text(tempo_blue, 60, 260);
			}else{
				blue1 = false;
				blue_ativado = false;
				tempo_blue = 0;
			}
			fill(0, 255, 255);
		}else{
			noFill();
		}
		image(upgradegelo, 35, 250, 35, 35);
	}
}

function upgrade_purple(){
	if(purple1 == true){
		if(purple_ativado == true){
			tempo_purple--;
			textFont(Font);
			textSize(25);
			fill(204, 102, 255);
			if(tempo_purple >= 0){
				textFont(Font);
				text(tempo_purple, 60, 310);
			}else{
				purple1 = false;
				purple_ativado = false;
				tempo_purple = 0;
			}

		}else{

		}
		image(upgradeshot, 35, 300, 35, 35);
	}
}

function tela_1(){
	tela1 = true;
}

function tela_2(){
	tela2 = true;
}

function tela_3(){
	tela3 = true
}

function tela_4(){
	tela4 = true;
}

function tela_5(){
	tela5 = true;
}

function tela_6(){
	tela6 = true
}

function tela_final(){
	background(backgroundMenu);
	textFont(Font);
	textSize(65);
	fill(255, 255, 255);
	text('END!', 90, 440);
	textSize(45);
	text('total score '+(score1+score2+score3), 90, 470);
}

function reset_1(){
	for(i = 0; i < 30; i++){
		inimigo1x[i] = random(20, width-40);
		inimigo1y[i] = random(-2000, -100);
		vel1y[i] = 1;
	}
}

function reset_2(){
	for(j = 0; j < 60; j++){
		inimigo2x[j] = random(20, width-40);
		inimigo2y[j] = random(-5000, -100);
		vel2y[j] = 1.8;
	}
}

function reset_3(){
	for(k = 0; k < 90; k++){
		inimigo3x[k] = random(20, width-40);
		inimigo3y[k] = random(-8000, -100);
		vel3y[k] = 2.5;
	}	
}

function reset_bonus(){
	for(r1 = 0; r1 < 1; r1++){
		redx[r1] = random(20, width-20);
		redy[r1] = random(-1500, -1000);
		velred[r1] = 2; 
	}
	for(r2 = 0; r2 < 2; r2++){
		redx[r2] = random(20, width-20);
		redy[r2] = random(-3000, -1000);
		velred[r2] = 2; 
	}
	for(r3 = 0; r3 < 3; r3++){
		redx[r3] = random(20, width-20);
		redy[r3] = random(-5000, -500);
		velred[r3] = 2; 
	}
}

function reset_upgrades(){
	orangex = random(20, width-20);
	orangey = random(-1000, -500);
	bluex = random(20, width-20);
	bluey = random(-1000, -500)
	purplex = random(20, width-20);
	purpley = random(-1000, -500);
}

function reset_variaveis(){
	orange1 = false;
	blue1 = false;
	purple1 = false;
	orange_ativiado = false;
	blue_ativado = false;
	purple_ativado = false;
	tempo_orange = 1000;
	tempo_blue = 600;
	tempo_purple = 600;
	velattack = 10;
	jogadorx = width/2;
	jogadory = 570;
	tiro = false;
	tiroy = jogadory + 200;
	qt_inimigo1 = 0;
	qt_inimigo2 = 0;
	qt_inimigo3 = 0;
}

function collide_upgrade_1(){
	orangey = orangey + 2;
	image(upgradevel, orangex, orangey, 30, 30);

	if(distanciavelocidade<30){
		orangey = 1000;
		orange1 = true;
	}
}

function collide_upgrade_2(){
	bluey = bluey + 2;
	image(upgradegelo, bluex, bluey, 30, 30);

	if(distanciagelo<30){
		bluey = 1000;
		blue1 = true;
	}
}

function collide_upgrade_3(){
	noStroke();
	fill(204, 102, 255);
	purpley = purpley + 2;
	image(upgradeshot, purplex, purpley, 30, 30);

	if(distanciashot<30){
		purpley = 1000;
		purple1 = true;
	}
}